//////////////////// ALL ASSIGNMENTS INCLUDE THIS SECTION /////////////////////
//
// Title:           BlockLinkedLists
// Files:           LinkedMegaBlock.java, LinkedListMegaBlock.java, MegaBlockBuilderTester.java
// Course:          CS 300, Fall, 2019
//
// Author:          Samuel Bahr
// Email:           sdbahr@wisc.edu
// Lecturer's Name: Gary Dahl
//
//////////////////// PAIR PROGRAMMERS COMPLETE THIS SECTION ///////////////////
//
// Partner Name:    Adam Shedivy
// Partner Email:   ajshedivy@wisc.edu
// Partner Lecturer's Name: Gary Dahl
// 
// VERIFY THE FOLLOWING BY PLACING AN X NEXT TO EACH TRUE STATEMENT:
//   X   Write-up states that pair programming is allowed for this assignment.
//   X   We have both read and understand the course Pair Programming Policy.
//   X   We have registered our team prior to the team registration deadline.
//
///////////////////////////// CREDIT OUTSIDE HELP /////////////////////////////
//
// Students who get help from sources other than their partner must fully 
// acknowledge and credit those sources of help here.  Instructors and TAs do 
// not need to be credited here, but tutors, friends, relatives, room mates, 
// strangers, and others do.  If you received no outside help from either type
//  of source, then please explicitly indicate NONE.
//
// Persons:         N/A
// Online Sources:  N/A
//
/////////////////////////////// 80 COLUMNS WIDE ///////////////////////////////

/**
 * @author Samuel Bahr
 * 
 *         The MegaBlockBuiderTester class contains 6 methods which perform
 *         multiple tests on the LinkedListMegaBlock and LinkedMegaBlock classes
 *
 */
public class MegaBlockBuilderTester {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		testLinked();
		testMegaBlockEquals();
		testMegaBlockToString();
		testLinkedMegaBlock();
		testLinkedMegaBlockListAddRed();
		testLinkedMegaBlockListAddRed();

	}

	public static boolean testLinked() {
		LinkedMegaBlock aBlock = new LinkedMegaBlock(new MegaBlock(Color.RED, 'a'));
		LinkedMegaBlock aBlock2 = new LinkedMegaBlock(new MegaBlock(Color.BLUE, 'b'));
		aBlock.setNext(aBlock2);
		System.out.println(aBlock.toString());
		return true;
	}

	/**
	 * @return A boolean value which represents a Pass or Fail on the test method
	 */
	public static boolean testMegaBlockEquals() {
		MegaBlock block = new MegaBlock(Color.RED, 'd'); // Creates a new MegaBlock Object
		MegaBlock block2 = new MegaBlock(Color.RED, 'e');// Creates the same MegaBlock Object
		if (block.equals(block2)) { // Tests whether the two objects equal each other.
			return true;
		}
		return false;
	}

	/**
	 * @return A boolean value which represents a Pass or Fail on the test method
	 */
	public static boolean testMegaBlockToString() {
		MegaBlock block = new MegaBlock(Color.BLUE, 'f'); // Creates new MegaBlock object
		String string = block.toString(); // calls toString Method and assigns the output to a string
		String[] splitString = string.split(""); // splits string into an array based upon a space
		if (splitString[0].equals("BLUE") && splitString[1].equals('f')) { // Checks for toString accuracy
			return true;
		}
		return false;
	}

	/**
	 * @return A boolean value which represents a Pass or Fail on the test method
	 *         Tests for Success of a Constructor, Accessor, and Mutator
	 */
	public static boolean testLinkedMegaBlock() {
		int count = 0; // Multiple Test
		LinkedMegaBlock block = new LinkedMegaBlock(new MegaBlock(Color.RED, 'd'));
		block.setBlock(new MegaBlock(Color.BLUE, 'e')); // Sets a Block
		if (block.getBlock().getColor() == Color.BLUE) { // Gets the same block
			count++; // Increments if the Statement is true
		}
		MegaBlock testBlock = block.getBlock(); // Tests Accessor Method
		if (testBlock.equals(block)) {
			count++; // Increments if the statement is true
		}
		if (count == 2) {
			return true;
		}
		return false;

	}

	// checks for the correctness of the LinkedListMegaBlock.addRed() method
	/**
	 * @return A boolean value which represents a Pass or Fail on the test method
	 */
	public static boolean testLinkedMegaBlockListAddRed() {
		int count = 0; // Multiple Tests
		LinkedListMegaBlock block = new LinkedListMegaBlock();
		block.addRed(new MegaBlock(Color.RED, 'd')); // Populating the LinkedListMegaBlock object
		if (block.get(0).getColor() == Color.RED) { // Tests whether the head contains the Color.Red object
			count++;
		}
		if (block.get(0) != null) { // Also checks if the head is null
			count++;
		}
		if (count == 2) { // Passes if both test pass
			return true;
		}
		return false;

	}

	// checks for the correctness of the LinkedListMegaBlock.removeBlue() method
	/**
	 * @return A boolean value which represents a Pass or Fail on the test method
	 */
	public static boolean testLinkedListMegaBlockRemoveBlue() {
		LinkedListMegaBlock block = new LinkedListMegaBlock();
		block.addRed(new MegaBlock(Color.RED, 'a')); // Populating the LinkedListMegaBlock
		block.addRed(new MegaBlock(Color.RED, 'b'));
		block.addRed(new MegaBlock(Color.RED, 'c'));
		block.addRed(new MegaBlock(Color.RED, 'd'));
		block.addYellow(4, new MegaBlock(Color.YELLOW, 'e'));
		block.addYellow(5, new MegaBlock(Color.YELLOW, 'f'));
		MegaBlock secondToLast = new MegaBlock(Color.BLUE, 'g'); // used within the test
		block.addBlue(secondToLast);
		block.addBlue(new MegaBlock(Color.BLUE, 'h'));
		block.removeBlue(); // removes the tail
		if (block.get(block.size() - 1).equals(secondToLast)) { // Tests if the tail was successfully removed, and a
																// shift within the LinkedListMegaBlock object
			return true;
		}
		return false;

	}

}
